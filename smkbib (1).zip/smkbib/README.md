# Website Resmi SMK Bina Insan Bangsa (SMK BIB)

Situs statis (HTML/CSS/JS) + backend **Supabase** (PostgreSQL, Auth, Storage) + deploy otomatis **GitHub Pages**.
Tidak butuh proses build. Semua tombol, form, dan dashboard terhubung ke database.

## Isi proyek

| Path | Fungsi |
|---|---|
| `index.html`, `profil.html`, `program.html`, `guru.html`, `fasilitas.html`, `berita.html`, `galeri.html`, `prestasi.html`, `ppdb.html`, `kontak.html` | 10 menu situs publik |
| `admin/` | Dashboard admin (login aman) |
| `supabase/schema.sql` | Tabel, keamanan RLS, storage, data awal |
| `assets/js/config.js` | **Satu-satunya file yang perlu diisi** (URL + anon key Supabase) |
| `.github/workflows/pages.yml` | Deploy otomatis ke GitHub Pages |
| `sitemap.xml`, `robots.txt` | SEO |

## Langkah pemasangan (±20 menit)

### 1. Buat project Supabase
1. Daftar di supabase.com, **New project** (pilih region Singapore).
2. Buka **SQL Editor > New query**, tempel seluruh isi `supabase/schema.sql`, klik **Run**.

### 2. Hubungkan situs
Di Supabase: **Project Settings > API**. Salin **Project URL** dan **anon public key** ke `assets/js/config.js`.
Jangan pernah memakai `service_role key` di situs.

### 3. Buat akun admin
1. Supabase > **Authentication > Users > Add user**: isi email + password, centang *Auto Confirm*.
2. Di SQL Editor jalankan (ganti emailnya):
   ```sql
   insert into public.admins (user_id)
   select id from auth.users where email = 'email-admin@contoh.com';
   ```
3. Di **Authentication > URL Configuration**, isi *Site URL* dengan alamat situs (agar fitur "Lupa password" bekerja).
4. Matikan pendaftaran publik: **Authentication > Providers > Email > nonaktifkan "Allow new users to sign up"**.

### 4. Deploy lewat GitHub (GitHub Pages)
1. Buat repositori baru di github.com (mis. `smkbib`), lalu unggah seluruh isi folder ini ke branch `main`
   (`git init && git add . && git commit -m "Website SMK BIB" && git branch -M main && git remote add origin <url-repo> && git push -u origin main`).
2. Di repositori: **Settings > Pages > Build and deployment > Source: GitHub Actions**.
3. Setiap `push` ke `main` otomatis men-deploy situs (lihat tab **Actions**). Alamat awal: `https://<akun>.github.io/<repo>/`.
4. **Domain sendiri (disarankan):** Settings > Pages > Custom domain, isi domain sekolah, atur DNS sesuai petunjuk GitHub, lalu centang **Enforce HTTPS**. Gunakan domain di root (bukan sub-folder `/<repo>/`) agar halaman 404 dan tautan SEO benar.
5. Jika domain bukan `smkbibngamprah.sch.id`, ganti alamat itu di `sitemap.xml`, `robots.txt`, `config.js`, dan tag `canonical`/`og:url` pada setiap halaman HTML.
6. Tambahkan alamat situs ke Supabase: **Authentication > URL Configuration > Site URL**.

> `assets/js/config.js` berisi URL dan anon key Supabase. Ini **memang boleh publik** (keamanan dijaga RLS), jadi aman berada di repositori. Jangan pernah mengunggah `service_role key`.

### 5. Isi konten lewat `alamat-situs/admin/`
Ikuti daftar "Yang perlu dilengkapi" di halaman Ringkasan dashboard.

## Yang HARUS dikonfirmasi sekolah sebelum dipublikasikan

- **Program keahlian** (TKJ, TBSM, BDP) dibuat dalam status *Draf*; aktifkan di dashboard setelah dipastikan masih dibuka. Deskripsinya bersifat umum, sesuaikan dengan kurikulum sekolah.
- **Akreditasi A**: isi masa berlaku di Identitas & Logo.
- **Kata "Keunggulan"** di beranda berasal dari contoh pada brief; ubah/hapus di Profil, Visi & Misi jika tidak sesuai.
- Visi, misi, sejarah, kepala sekolah, guru, fasilitas, dan prestasi sengaja **kosong** (tidak dikarang).
- **PPDB**: formulir baru tampil jika "Buka formulir pendaftaran online" dicentang. Isi jadwal dan biaya hanya setelah dikonfirmasi.

## Keamanan dan cadangan

- Data pendaftar dan pesan: publik hanya bisa **mengisi**, hanya admin yang bisa **membaca** (RLS). Dokumen PPDB disimpan di bucket privat.
- Pustaka `supabase-js` dimuat dari CDN jsDelivr (versi mayor 2). Untuk keamanan maksimal, kunci ke versi tetap dan tambahkan atribut SRI.
- Cadangan: paket Supabase gratis **tidak** memiliki backup otomatis. Gunakan tombol **Ekspor CSV** di Data Pendaftar secara berkala, atau upgrade ke paket Pro (backup harian).
- Kebijakan keamanan konten (CSP) dipasang lewat meta tag; HTTPS dari GitHub Pages.
- Foto dikompres otomatis (maks. 1600 px, WebP) saat diunggah.
- Halaman berita/program dirender oleh JavaScript; judul tab diperbarui otomatis, tetapi sitemap hanya memuat halaman utama.
